package cn.zhaiyy.demo.service;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.junit.jupiter.api.Test;
import org.springframework.util.Assert;

class AuthorServiceTest {

    @Test
    void getName() throws Exception {
        JaxWsDynamicClientFactory factory = JaxWsDynamicClientFactory.newInstance();
        // wsdl地址
        Client client = factory.createClient("http://localhost:8080/services/authorService?wsdl");
        // getName为方法名，zhaiyy为方法的参数，可以有多个
        // objs为方法的返回值
        Object[] objs = client.invoke("getName", "zhaiyy");
        Assert.notNull(objs, "getName结果返回空");
    }
}
