package cn.zhaiyy.demo.config;

import cn.zhaiyy.demo.service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.apache.cxf.Bus;
import javax.xml.ws.Endpoint;
import org.apache.cxf.jaxws.EndpointImpl;

@Configuration
public class CxfConfig {

    @Autowired
    private Bus bus;   //private SpringBus bus;

    @Autowired
    private AuthorService authorService;

    /**
     * 具体的访问地址为: {{服务地址}}/services/发布地址
     * @return
     */
    @Bean
    public Endpoint endpoint() {
        EndpointImpl endpoint = new EndpointImpl(bus, authorService);
        endpoint.publish("/authorService");   //发布地址
        return endpoint;
    }
}
