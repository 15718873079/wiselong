package cn.zhaiyy.demo.service;

import org.springframework.stereotype.Component;

import javax.jws.WebService;

@WebService
@Component
public interface AuthorService {

    public String getName(String name);
}
