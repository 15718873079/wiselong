package cn.zhaiyy.demo.service;

import org.springframework.stereotype.Component;

import javax.jws.WebService;

@WebService(
        name = "AuthorService",
        /**
         * 1. 如果接口和其实现类在同一个包下，此参数可以不加
         * 2、 如果不在一个包下，具体值为： http://{{接口包名的倒叙}}/ ,最后的/不要漏了
         * 3、 此参数的值还可以在服务启动后，访问wsdl文件，找targetNamespace属性。
        */
        targetNamespace = "http://service.demo.zhaiyy.cn/",

        // 接口的包名 + 接口名
        endpointInterface = "cn.zhaiyy.demo.service.AuthorService"
)
@Component
public class AuthorServiceImpl implements AuthorService {

    @Override
    public String getName(String name) {
        return "your name is :" + name;
    }
}
